
readme.txt - $Version$


LICENSING

This software is distributed under the terms of the LGPL license.


USING JBOSS SERIALIZATION

1.  You just need to instantiate your ObjectOutputStream as new JBossObjectOutputStream, and your input stream as JBossObjectInputStream.
2.  You will need to add log4j.jar and trove.jar in your library dependencies, as these classes are used by jboss-serialization.
3.  Make sure you also include log4j.xml in your classpath. (If you miss it, DEBUG statements will be used by default what will cause really bad performance serializing your objects)

COMPATIBILITY WITH OBJECT SERIALIZATION

1.  There is no compatibility between JBossSerialization's and JavaSerialization's protocol. We have made optimizations to the streaming hence the output is not compatible each other.


NOTES

1.  In case you need support to reset commands, and having multiple objects sharing the same object tree between distinct read and writeObjects, use JBossObjectInputStreamSharedTree
2.  There are two MarshalledObjects under org.jboss.serial.io. MarshalledObject and MarshalledObjectForLocalCalls. MarshalledObjectForLocalCalls will use te DataContainer for fast call-by-value operations.


More information available at http://www.jboss.org